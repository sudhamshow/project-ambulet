 sh -x threeg_bw/wget_bw.sh ppp1 docomo dtemp&
	
 sh -x threeg_bw/wget_bw.sh ppp0 bsnl btemp &

 sh -x threeg_bw/wget_bw.sh ppp2 airtel atemp 
