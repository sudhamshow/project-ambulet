/**
 * Copyright (c) 2009 DEXMA SENSORS SL
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the
 *   distribution.
 * - Neither the name of the DEXMA SENSORS SL nor the names of
 *   its contributors may be used to endorse or promote products derived
 *   from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
 * DEXMA SENSORS SL OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE
 */
 
 /**
 * Copyright (c) 2005-2006 Arched Rock Corporation
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the
 *   distribution.
 * - Neither the name of the Arched Rock Corporation nor the names of
 *   its contributors may be used to endorse or promote products derived
 *   from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
 * ARCHED ROCK OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE
 */

/**
 * @author Jonathan Hui <jhui@archedrock.com>
 * @author Xavier Orduna <xorduna@dexmatech.com>
 * @version $Revision: 1.5 $ $Date: 2008/05/21 22:11:57 $
 */

configuration Msp430UsciShareB0P {

  provides interface HplMsp430UsciInterrupts as Interrupts[ uint8_t id ];
  provides interface Resource[ uint8_t id ];
  provides interface ResourceRequested[ uint8_t id ];
  provides interface ArbiterInfo;

  uses interface ResourceConfigure[ uint8_t id ];
}

implementation {

  components new Msp430UsciShareP() as UsciShareP;
  Interrupts = UsciShareP;
  
  components new FcfsArbiterC( MSP430_HPLUSCIB0_RESOURCE ) as ArbiterC;
  Resource = ArbiterC;
  ResourceRequested = ArbiterC;
  ResourceConfigure = ArbiterC;
  ArbiterInfo = ArbiterC;
  UsciShareP.ArbiterInfo -> ArbiterC;

  components HplMsp430UsciB0C as HplUsciC;
  UsciShareP.RawInterrupts -> HplUsciC;

}
                                  *PPD-Adobe: "4.1"
*% Adobe Systems PostScript(R) Printer Description File
*% Copyright 1987-1994 Adobe Systems Incorporated. 
*% All Rights Reserved. 
*% Permission is granted for redistribution of this file as
*% long as this copyright notice is intact and the contents
*% of the file is not altered in any way from its original form.
*% End of Copyright statement
*FormatVersion: "4.1"
*FileVersion: "1.2"
*LanguageEncoding: ISOLatin1
*LanguageVersion: English
*PCFileName: "HP3SIL21.PPD"
*Product: "(HP LaserJet IIISi)"
*PSVersion: "(2012.021) 2"
*ModelName: "HP LaserJet IIISi Postscript 2"
*ShortNickName: "HP LaserJet IIISi Postscript 2"
*NickName: "HP LaserJet IIISi Postscript 2 v2012.021"

*% === Options and Constraints =========

*OpenGroup: InstallableOptions/Options Installed
*OpenUI *Option1/Optional Envelope Feeder: Boolean
*DefaultOption1: False
*Option1 True/Installed: ""
*Option1 False/Not Installed: ""
*CloseUI: *Option1

*OpenUI *Option2/Memory Configuration: PickOne
*DefaultOption2: None
*Option2 None/Standard 2 MB RAM: ""
*Option2 3Meg/3 MB Total RAM: ""
*Option2 4Meg/4 MB Total RAM: ""
*Option2 5Meg/5 MB Total RAM: ""
*Option2 6Meg/6 MB Total RAM: ""
*Option2 7Meg/7 MB Total RAM: ""
*Option2 9Meg/9 MB Total RAM: ""
*Option2 10Meg/10 MB Total RAM: ""
*Option2 11Meg/11 MB Total RAM: ""
*Option2 13Meg/13 MB Total RAM: ""
*Option2 14Meg/14 MB Total RAM: ""
*Option2 17Meg/17 MB Total RAM: ""
*CloseUI: *Option2
*CloseGroup: InstallableOptions

*UIConstraints: *Option1 False *InputSlot Envelope
*UIConstraints: *Option2 None *Duplex
*UIConstraints: *Option2 3Meg *Duplex

*UIConstraints: *PageSize Letter *InputSlot Envelope
*UIConstraints: *PageSize Legal *InputSlot Envelope
*UIConstraints: *PageSize Executive *InputSlot Envelope
*UIConstraints: *PageSize A4 *InputSlot Envelope
*UIConstraints: *InputSlot Envelope *PageSize Letter
*UIConstraints: *InputSlot Envelope *PageSize Legal
*UIConstraints: *InputSlot Envelope *PageSize Executive
*UIConstraints: *InputSlot Envelope *PageSize A4
*UIConstraints: *PageRegion Letter *InputSlot Envelope
*UIConstraints: *PageRegion Legal *InputSlot Envelope
*UIConstraints: *PageRegion Executive *InputSlot Envelope
*UIConstraints: *PageRegion A4 *InputSlot Envelope
*UIConstraints: *InputSlot Envelope *PageRegion Letter
*UIConstraints: *InputSlot Envelope *PageRegion Legal
*UIConstraints: *InputSlot Envelope *PageRegion Executive
*UIConstraints: *InputSlot Envelope *PageRegion A4

*UIConstraints: *PageSize Comm10 *Duplex
*UIConstraints: *PageSize Monarch *Duplex
*UIConstraints: *PageSize DL *Duplex
*UIConstraints: *Duplex *PageSize Comm10
*UIConstraints: *Duplex *PageSize Monarch
*UIConstraints: *Duplex *PageSize DL
*UIConstraints: *PageRegion Comm10 *Duplex
*UIConstraints: *PageRegion Monarch *Duplex
*UIConstraints: *PageRegion DL *Duplex
*UIConstraints: *Duplex *PageRegion Comm10
*UIConstraints: *Duplex *PageRegion Monarch
*UIConstraints: *Duplex *PageRegion DL


*% ==== Device Capabilities ===============
*LanguageLevel: "2"

*FreeVM: "272283"
*VMOption None/Standard: "272283"
*VMOption 3Meg/3 MB Total RAM: "1320834"
*VMOption 4Meg/4 MB Total RAM: "2378002"
*VMOption 5Meg/5 MB Total RAM: "2214162"
*VMOption 6Meg/6 MB Total RAM: "3262738"
*VMOption 7Meg/7 MB Total RAM: "4303122"
*VMOption 9Meg/9 MB Total RAM: "6391690"
*VMOption 10Meg/10 MB Total RAM: "7435532"
*VMOption 11Meg/11 MB Total RAM: "848108"
*VMOption 13Meg/13 MB Total RAM: "10594578"
*VMOption 14Meg/14 MB Total RAM: "11643154"
*VMOption 17Meg/17 MB Total RAM: "14780298"

*ColorDevice: False
*DefaultColorSpace: Gray
*VariablePaperSize: False
*Throughput: "17"

*Password: "()" 
*ExitServer: "
 count 0 eq
 { false } { true exch startjob } ifelse
 not { 
     (WARNING: Cannot modify initial VM.) =
     (Missing or invalid password.) =
     (Please contact the author of this software.) = flush quit
     } if
"
*End

*Reset: "
 count 0 eq
 { false } { true exch startjob } ifelse
 not { 
    (WARNING: Cannot reset printer.) =
    (Missing or invalid password.) =
    (Please contact the author of this software.) = flush quit
    } if
 systemdict /quit get exec
 (WARNING : Printer Reset Failed.) = flush
"
*End

*DefaultResolution: 300dpi
*?Resolution: "
  save
    currentpagedevice /HWResolution get
    0 get
    (          ) cvs print
    (dpi)
    = flush
  restore
"
*End

*% Halftone Information ===============
*ScreenFreq: "60.0"
*ScreenAngle: "45.0"
*DefaultScreenProc: Dot
*ScreenProc Dot: "
{abs   exch   abs   2 copy   add   1 gt   {1 sub   dup   mul   exch  
1 sub   dup   mul   add   1 sub  } {dup   mul   exch   dup   mul  
add   1 exch   sub  } ifelse  }
"
*End
*ScreenProc Line: "{ pop }"
*ScreenProc Ellipse: "{ dup 5 mul 8 div mul exch dup mul exch add sqrt 1 exch sub }"

*DefaultTransfer: Null
*Transfer Null: "{ }"
*Transfer Null.Inverse: "{ 1 exch sub }"

*OpenUI *Smoothing/Resolution Enhancement:  PickOne
*OrderDependency: 50 AnySetup *Smoothing
*DefaultSmoothing: Medium
*Smoothing None/Off: " 
    1 dict
    dup /Policies 2 dict dup /PageSize 2 put dup /MediaType 0 put put
	setpagedevice
    2 dict 
    dup /PostRenderingEnhance true put
    dup /PostRenderingEnhanceDetails
      2 dict dup /REValue 0 put dup /Type 8 put put
    setpagedevice"
*End
*Smoothing Light: "
     1 dict
    dup /Policies 2 dict dup /PageSize 2 put dup /MediaType 0 put put
	setpagedevice
    2 dict 
    dup /PostRenderingEnhance true put
    dup /PostRenderingEnhanceDetails
      2 dict dup /REValue 1 put dup /Type 8 put put
    setpagedevice"
*End
*Smoothing Medium: "
    1 dict
    dup /Policies 2 dict dup /PageSize 2 put dup /MediaType 0 put put
	setpagedevice
    2 dict 
    dup /PostRenderingEnhance true put
    dup /PostRenderingEnhanceDetails
      2 dict dup /REValue 2 put dup /Type 8 put put
    setpagedevice"
*End
*Smoothing Dark: "
    1 dict
    dup /Policies 2 dict dup /PageSize 2 put dup /MediaType 0 put put
	setpagedevice
    2 dict 
    dup /PostRenderingEnhance true put
    dup /PostRenderingEnhanceDetails 
      2 dict dup /REValue 3 put dup /Type 8 put put
    setpagedevice"
*End
*?Smoothing: "
  save
    currentpagedevice /PostRenderingEnhanceDetails get /REValue get
    [(None) (Light) (Medium) (Dark)]  exch get print
  restore
"
*End
*CloseUI: *Smoothing

*% Paper Handling ===================

*% Code in this section both selects a tray and sets up a frame buffer.
*OpenUI *PageSize: PickOne
*OrderDependency: 30 AnySetup *PageSize
*DefaultPageSize: Letter
*PageSize Letter/Letter 8 1/2 x 11 in: "
    2 dict dup /PageSize [612 792] put dup /ImagingBBox null put setpagedevice"
*End
*PageSize Legal/Legal 8 1/2 x 14 in: "
    2 dict dup /PageSize [612 1008] put dup /ImagingBBox null put setpagedevice"
*End
*PageSize A4/A4 210 x 297 mm: "
    2 dict dup /PageSize [595 842] put dup /ImagingBBox null put setpagedevice"
*End
*PageSize Executive/Executive 7 1/4 x 10 1/2 in: "
    2 dict dup /PageSize [522 756] put dup /ImagingBBox null put setpagedevice"
*End
*PageSize Comm10/Env Comm10 4 1/8 x 9 1/2 in: "
    2 dict dup /PageSize [297 684] put dup /ImagingBBox null put setpagedevice"
*End
*PageSize Monarch/Env Monarch 3 7/8 x 7 1/2 in : "
    2 dict dup /PageSize [279 540] put dup /ImagingBBox null put setpagedevice"
*End
*PageSize DL/Env DL 110 x 220 mm: "
    2 dict dup /PageSize [312 624] put dup /ImagingBBox null put setpagedevice"
*End
*?PageSize: "
 save
   currentpagedevice /PageSize get aload pop
   2 copy gt {exch} if 
   (Unknown) 
  7 dict
   dup [612 792] (Letter) put
   dup [612 1008] (Legal) put
   dup [595 842] (A4) put
   dup [522 756] (Executive) put
   dup [297 684] (Comm10) put
   dup [279 540] (Monarch) put
   dup [312 624] (DL) put
 { exch aload pop 4 index sub abs 5 le exch 
   5 index sub abs 5 le and 
      {exch pop exit} {pop} ifelse
   } bind forall
   = flush pop pop
restore 
"
*End
*CloseUI: *PageSize

*OpenUI *PageRegion:  PickOne
*OrderDependency: 40 AnySetup *PageRegion
*DefaultPageRegion: Letter
*PageRegion Letter/Letter 8 1/2 x 11 in: "
    2 dict dup /PageSize [612 792] put dup /ImagingBBox null put setpagedevice"
*End
*PageRegion Legal/Legal 8 1/2 x 14 in: "
    2 dict dup /PageSize [612 1008] put dup /ImagingBBox null put setpagedevice"
*End
*PageRegion A4/A4 210 x 297 mm: "
    2 dict dup /PageSize [595 842] put dup /ImagingBBox null put setpagedevice"
*End
*PageRegion Executive/Executive 7 1/4 x 10 1/2 in: "
    2 dict dup /PageSize [522 756] put dup /ImagingBBox null put setpagedevice"
*End
*PageRegion Comm10/Env Comm10 4 1/8 x 9 1/2 in: "
    2 dict dup /PageSize [297 684] put dup /ImagingBBox null put setpagedevice"
*End
*PageRegion Monarch/Env Monarch 3 7/8 x 7 1/2 in: "
    2 dict dup /PageSize [279 540] put dup /ImagingBBox null put setpagedevice"
*End
*PageReg