/**
 * Copyright (c) 2010 Eric B. Decker
 * All rights reserved.
 *
 * Copyright (c) 2009-2010 DEXMA SENSORS SL
 * All rights reserved.
 *
 * Copyright (c) 2004-2006, Technische Universitaet Berlin
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 *
 * - Neither the name of Eric Decker, DEXMA SENSORS SL, the Technische
 *   Universitaet Berlin nor the names of its contributors may be used
 *   to endorse or promote products derived from this software without
 *   specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


/**
 * @author Vlado Handziski <handzisk@tkn.tu-berlin.de>
 * @author Philipp Huppertz <huppertz@tkn.tu-berlin.de>
 * @author Xavier Orduna <xorduna@dexmatech.com>
 * @author Eric B. Decker <cire831@gmail.com>
 * @author Jordi Soucheiron <jsoucheiron@dexmatech.com>
 *
 * Fix to reflect the MSP430X as documented in Users guide
 * slau144e, msp430f2618.
 */

#ifndef _H_MSP430USCI_H
#define _H_MSP430USCI_H

/*
 * The MSP430X architecture at least the msp430f2618 family
 * has a total of four ports that can be used independently
 * usciA0, A1 (uart, spi) and usciB0, B1 (i2c, spi only).
 *
 * We set the resources up so multiple use of a given port
 * can be arbritrated.
 *
 * UART0 -> usciA0	SPI2 -> usciA0
 * UART1 -> usciA1	SPI3 -> usciA1
 * SPI0  -> usciB0	I2C0
 * SPI1  -> usciB1	I2C1
 *
 * spi2,3 are mapped to usciA0,A1 because the typical
 * configuration is to use dual uarts and dual spis
 * so the less used configuration maps as 2 and 3.
 */

//USCI A0, A1: UART, SPI
#define MSP430_HPLUSCIA0_RESOURCE "Msp430UsciA0.Resource"
#define MSP430_HPLUSCIA1_RESOURCE "Msp430UsciA1.Resource"
#define MSP430_UART0_BUS          MSP430_HPLUSCIA0_RESOURCE
#define MSP430_UART1_BUS          MSP430_HPLUSCIA1_RESOURCE
#define MSP430_SPI2_BUS           MSP430_HPLUSCIA0_RESOURCE
#define MSP430_SPI3_BUS           MSP430_HPLUSCIA1_RESOURCE

//USCI B0, B1: SPI,  I2C
#define MSP430_HPLUSCIB0_RESOURCE "Msp430UsciB0.Resource"
#define MSP430_HPLUSCIB1_RESOURCE "Msp430UsciB1.Resource"
#define MSP430_SPI0_BUS		  MSP430_HPLUSCIB0_RESOURCE
#define MSP430_SPI1_BUS		  MSP430_HPLUSCIB1_RESOURCE
#define MSP430_I2C0_BUS		  MSP430_HPLUSCIB0_RESOURCE
#define MSP430_I2C1_BUS		  MSP430_HPLUSCIB1_RESOURCE

typedef enum {
  USCI_NONE = 0,
  USCI_UART = 1,
  USCI_SPI = 2,
  USCI_I2C = 3
} msp430_uscimode_t;


/************************************************************************************************************
 *
 * UART mode definitions
 *
 */

/*
 * UCAxCTL0, UART control 0, uart mode
 */

typedef struct {
  unsigned int ucsync : 1;   // Synchronous mode enable (0=Asynchronous; 1:Synchronous)
  unsigned int ucmode : 2;   // USCI Mode (00=UART Mode; 01=Idle-Line; 10=Addres-Bit; 11=UART Mode, auto baud rate detection)
  unsigned int ucspb  : 1;    // Stop bit select. Number of stop bits (0=One stop bit; 1=Two stop bits)
  u