 BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of l/**
 * \addtogroup loader
 * @{
 */

/**
 * \defgroup elfloader The Contiki ELF loader
 *
 * The Contiki ELF loader links, relocates, and loads ELF
 * (Executable Linkable Format) object files into a running Contiki
 * system.
 *
 * ELF is a standard format for relocatable object code and executable
 * files. ELF is the standard program format for Linux, Solaris, and
 * other operating systems.
 *
 * An ELF file contains either a standalone executable program or a
 * program module. The file contains both the program code, the
 * program data, as well as information about how to link, relocate,
 * and load the program into a running system.
 *
 * The ELF file is composed of a set of sections. The sections contain
 * program code, data, or relocation information, but can also contain
 * debugging information.
 *
 * To link and relocate an ELF file, the Contiki ELF loader first
 * parses the ELF file structure to find the appropriate ELF
 * sections. It then allocates memory for the program code and data in
 * ROM and RAM, respectively. After allocating memory, the Contiki ELF
 * loader starts relocating the code found in the ELF file.
 *
 * @{
 */

/**
 * \file
 *         Header file for the Contiki ELF loader.
 * \author
 *         Adam Dunkels <adam@sics.se>
 *
 */

/*
 * Copyright (c) 2005, Swedish Institute of Computer Science
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * This file is part of the Contiki operating system.
 *
 * @(#)$Id: elfloader.h,v 1.4 2010/04/26 14:02:07 fros4943 Exp $
 */
#ifndef __ELFLOADER_H__
#define __ELFLOADER_H__

#include "cfs/cfs.h"

/**
 * Return value from elfloader_load() indicating that loading worked.
 */
#define ELFLOADER_OK                  0
/**
 * Return value from elfloader_load() indicating that the ELF file had
 * a bad header.
 */
#define ELFLOADER_BAD_ELF_HEADER      1
/**
 * Return value from elfloader_load() indicating that no symbol table
 * could be found in the ELF file.
 */
#define ELFLOADER_NO_SYMTAB           2
/**
 * Return value from elfloader_load() indicating that no string table
 * could be found in the ELF file.
 */
#define ELFLOADER_NO_STRTAB           3
/**
 * Return value from elfloader_load() indicating that the size of the
 * .text segment was zero.
 */
#define ELFLOADER_NO_TEXT             4
/**
 * Return value from elfloader_load() indicating that a symbol
 * specific symbol could not be found.
 *
 * If this value is returned from elfloader_load(), the symbol has
 * been copied into the elfloader_unknown[] array.
 */
#define ELFLOADER_SYMBOL_NOT_FOUND    5
/**
 * Return value from elfloader_load() indicating that one of the
 * required segments (.data, .bss, or .text) could not be found.
 */
#define ELFLOADER_SEGMENT_NOT_FOUND   6
/**
 * Return value from elfloader_load() indicating that no starting
 * point could be found in the loaded module.
 */
#define ELFLOADER_NO_STARTPOINT       7

/**
 * elfloader initialization function.
 *
 * This function should be called at boot up to initialize the elfloader.
 */
void elfloader_init(void);

/**
 * \brief      Load and relocate an ELF file.
 * \param fd   An open CFS file descriptor.
 * \return     ELFLOADER_OK if loading and relocation worked.
 *             Otherwise an error value.
 *
 *             This function loads and relocates an ELF file. The ELF
 *             file must have been opened with cfs_open() prior to
 *             calling this function.
 *
 *             If the function is able to load the ELF file, a pointer
 *             to the process structure in the model is stored in the
 *             elfloader_loaded_process variable.
 *
 * \note       This function modifies the ELF file opened with cfs_open()!
 *             If the contents of the file is required to be intact,
 *             the file must be backed up first.
 *
 */
int elfloader_load(int fd);

/**
 * A pointer to the processes loaded with elfloader_load().
 */
extern struct process * const * elfloader_autostart_processes;

/**
 * If elfloader_load() could not find a specific symbol, it is copied
 * into this array.
 */
extern char elfloader_unknown[30];

#ifndef ELFLOADER_DATAMEMORY_SIZE
#ifdef ELFLOADER_CONF_DATAMEMORY_SIZE
#define ELFLOADER_DATAMEMORY_SIZE ELFLOADER_CONF_DATAMEMORY_SIZE
#else
#define ELFLOADER_DATAMEMORY_SIZE 0x100
#endif
#endif /* ELFLOADER_DATAMEMORY_SIZE */

#ifndef ELFLOADER_TEXTMEMORY_SIZE
#ifdef ELFLOADER_CONF_TEXTMEMORY_SIZE
#define ELFLOADER_TEXTMEMORY_SIZE ELFLOADER_CONF_TEXTMEMORY_SIZE
#else
#define ELFLOADER_TEXTMEMORY_SIZE 0x100
#endif
#endif /* ELFLOADER_TEXTMEMORY_SIZE */

typedef unsigned long  elf32_word;
typedef   signed long  elf32_sword;
typedef unsigned short elf32_half;
typedef unsigned long  elf32_off;
typedef unsigned long  elf32_addr;

struct elf32_rela {
  elf32_addr      r_offset;       /* Location to be relocated. */
  elf32_word      r_info;         /* Relocation type and symbol index. */
  elf32_sword     r_addend;       /* Addend. */
};


#endif /* __ELFLOADER_H__ */

/** @} */
/** @} */
                                                                                                                                                            OM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECE/*
 * Copyright (c) 2006, Swedish Institute of Computer Science
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the Contiki operating system.
 *
 * @(#)$Id: elfloader_compat.c,v 1.7 2008/02/07 15:53:43 oliverschmidt Exp $
 */

/*
 * This code is plug-in compatible with elfloader.c and is an example
 * of how the Contiki dynamic Link Editor (CLE) can be used.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "contiki.h"

#include "loader/elfloader_compat.h"
#include "loader/cle.h"

#include "lib/malloc.h"
#include "dev/rom.h"
#include "dev/xmem.h"

#define NDEBUG
#include "lib/assert.h"

#ifdef NDEBUG
#define PRINTF(...) do {} while (0)
#else
#define PRINTF(...) printf(__VA_ARGS__)
#endif

struct process *elfloader_loaded_process;
void (*elfloader_fini)(void);

#define IMAX(a, b) (((a) > (b)) ? (a) : (b))

unsigned char *datamemory;

#ifdef __AVR__
extern int __data_load_end;
#define TEXTMEMORY (((cle_addr)(&__data_load_end) + ROM_ERASE_UNIT_SIZE) \
		    & ~(ROM_ERASE_UNIT_SIZE - 1))
#else
#include <sys/unistd.h>
#define TEXTMEMORY \
    (cle_addr)(((uintptr_t)(&_etext + 1)                        \
		+ (uintptr_t)&_edata - (uintptr_t)&__data_start \
		+ ROM_ERASE_UNIT_SIZE)                          \
	       & ~(ROM_ERASE_UNIT_SIZE - 1))
#endif

char elfloader_unknown[30];	/* Name that caused link error. */

/*---------------------------------------------------------------------------*/
int
elfloader_load(off_t eepromaddr)
{
  struct cle_info h;
  int ret;

  void (*elfloader_init)(void);

  elfloader_unknown[0] = 0;

  /* The ELF header is located at the start of the buffer. */
  ret = cle_read_info(&h, xmem_pread, eepromaddr);

  if(ret != ELFLOADER_OK) {
    memcpy(elfloader_unknown, h.name, sizeof(elfloader_unknown));
    elfloader_unknown[sizeof(elfloader_unknown) - 1] = 0;
    return ret;
  }

  if(datamemory != NULL) {
    free(datamemory);
  }

  /* We are making semi-permanent allocations, first compact heap! */
  /* malloc_compact(); */
  datamemory = malloc(IMAX(h.textsize, h.datasize + h.bsssize));
  if(datamemory == NULL) {
    return ELFLOADER_DATA_TO_LARGE; /* XXX or text to large */
  }

  h.data = datamemory;
  h.bss = datamemory + h.datasize;
  h.text = TEXTMEMORY;

  PRINTF("elfloader: copy text segment to RAM %p %p\n",
	 h.data, h.data + h.textsize);
  ret = xmem_pread(datamemory, h.textsize, eepromaddr + h.textoff); 
  assert(ret > 0);
  if(h.textrelasize > 0) {
    PRINTF("elfloader: relocate text in RAM\n");
    ret = cle_relocate(&h,
		       xmem_pread,
		       eepromaddr,
		       datamemory,
		       h.textrelaoff, h.textrelasize);
    if(ret != ELFLOADER_OK) {
      memcpy(elfloader_unknown, h.name, sizeof(elfloader_unknown));
      elfloader_unknown[sizeof(elfloader_unknown) - 1] = 0;
      return ret;
    }
  }
  PRINTF("elfloader: copy text segment to ROM 0x%lx 0x%lx\n",
	 (unsigned long)h.text,
	 (unsigned long)h.text + h.textsize);

  ret = rom_erase((h.textsize+ROM_ERASE_UNIT_SIZE) & ~(ROM_ERASE_UNIT_SIZE-1),
		  h.text);
  assert(ret > 0);
  ret = rom_pwrite(datamemory, h.textsize, h.text);
  assert(ret > 0);

  PRINTF("elfloader: copy data segment to RAM %p %p\n",
	 h.data, h.data + h.datasize);
  ret = xmem_pread(datamemory, h.datasize, eepromaddr + h.dataoff); 
  assert(ret >= h.datasize);
  if(h.datarelasize > 0) {
    PRINTF("elfloader: relocate data segment\n");
    ret = cle_relocate(&h,
		       xmem_pread,
		       eepromaddr,
		       datamemory,
		       h.datarelaoff, h.datarelasize);
    if(ret != ELFLOADER_OK) {
      memcpy(elfloader_unknown, h.name, sizeof(elfloader_unknown));
      elfloader_unknown[sizeof(elfloader_unknown) - 1] = 0;
      return ret;
    }
  }

  PRINTF("elfloader: zero bss %p %p\n", h.bss, h.bss + h.bsssize);
  memset(h.bss, 0, h.bsssize);

  /* Find _init, _fini, and loaded_process. */
  elfloader_loaded_process = cle_lookup(&h, xmem_pread, eepromaddr,
					"autostart_processes");
  elfloader_fini = cle_lookup(&h, xmem_pread, eepromaddr, "_fini");
  elfloader_init = cle_lookup(&h, xmem_pread, eepromaddr, "_init");

  if(elfloader_init != NULL) {
    PRINTF("init=%p fini=%p\n", elfloader_init, elfloader_fini);
    (*elfloader_init)();
    elfloader_loaded_process = NULL;
    return ELFLOADER_OK;
  }

  if(elfloader_loaded_process != NULL) {
    PRINTF("elfloader: launch program\n");
    process_start(elfloader_loaded_process, NULL);
    elfloader_fini = NULL;
    return ELFLOADER_OK;
  } else {
    return ELFLOADER_NO_STARTPOINT;
  }
}
/*---------------------------------------------------------------------------*/
void
elfloader_unload(void)
{
  if(elfloader_fini != NULL) {
    (*elfloader_fini)();
    elfloader_fini = NULL;
  } else if(elfloader_loaded_process != NULL) {
    process_exit(elfloader_loaded_process);
    elfloader_loaded_process = NULL;
  }
  if(datamemory != NULL) {
    free(datamemory);
    datamemory = NULL;
  }
}
                                                                                                                                                                                                                           0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of /*
 * Copyright (c) 2005, Swedish Institute of Computer Science
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the Contiki operating system.
 *
 * @(#)$Id: elfloader_compat.h,v 1.1 2006/12/20 13:38:33 bg- Exp $
 */
#ifndef __ELFLOADER_H__
#define __ELFLOADER_H__

#define ELFLOADER_OK                  0
#define ELFLOADER_BAD_ELF_HEADER      1
#define ELFLOADER_NO_SYMTAB           2
#define ELFLOADER_NO_STRTAB           3
#define ELFLOADER_NO_TEXT             4
#define ELFLOADER_SYMBOL_NOT_FOUND    5
#define ELFLOADER_SEGMENT_NOT_FOUND   6
#define ELFLOADER_NO_STARTPOINT       7
#define ELFLOADER_TEXT_TO_LARGE       8
#define ELFLOADER_DATA_TO_LARGE       9
#define ELFLOADER_BSS_TO_LARGE       10

int elfloader_load(off_t eepromaddr);
void elfloader_unload(void);

extern struct process *elfloader_loaded_process;
extern void (*elfloader_fini)(void);
extern char elfloader_unknown[30];

#endif /* __ELFLOADER_H__ */
                                                                                                                     ED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED FROM BS of length 0
PKT RECEIVED F