#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <errno.h>
#include <curses.h>
#include <time.h>
#include <signal.h>
#ifndef S_SPLINT_S
#include <unistd.h>
#endif /* S_SPLINT_S */
#include <ctype.h>

#include "gpsd_config.h"
#include "gps.h"
#include "gpsdclient.h"
#include "revision.h"

main(){
	
	struct gps_data_t *gpsdata;
//	gpsdata = calloc(1 ,sizeof(struct gps_data_t));
	gpsdata = malloc(sizeof(struct gps_data_t));
	bzero(gpsdata,(sizeof(struct gps_data_t)));
/*	while(1){
		getGPSData(gpsdata);
		printf("lat= %lf lon= %lf\n",gpsdata->fix.latitude,gpsdata->fix.longitude);
	}
*/
		getGPSData(gpsdata);
}

int getGPSData(struct gps_data_t *gpsdata){
    if(gps_open("localhost", "2947", gpsdata)<0){
        fprintf(stderr,"Could not connect to GPSd\n");
        return(-1);
    }

    gps_stream(gpsdata, WATCH_ENABLE | WATCH_JSON, NULL);
     
    fprintf(stderr,"Waiting for gps lock.");
	   while(gpsdata->status==0){
		if (gps_waiting(gpsdata, 500)){
		   if(gps_read(gpsdata)==-1){
                	fprintf(stderr,"GPSd Error\n");
                	gps_stream(gpsdata, WATCH_DISABLE, NULL);
                	gps_close(gpsdata);
                	return(-1);
                	break;
            		}
            	else{
		   if(gpsdata->status>0){
                    //sometimes if your GPS doesnt have a fix, it sends you data anyways
                    //                    //the values for the fix are NaN. this is a clever way to check for NaN.
                     if(gpsdata->fix.longitude!=gpsdata->fix.longitude || gpsdata->fix.altitude!=gpsdata->fix.altitude){
                     fprintf(stderr,"Could not get a GPS fix.\n");
                     gps_stream(gpsdata, WATCH_DISABLE, NULL);
                     gps_close(gpsdata);
                     return(-1);
                     }else{
                        fprintf(stderr,"\n");
		     }
                   }else{
                    fprintf(stderr,".");
		   }
                }
        }else{
            gps_stream(gpsdata, WATCH_ENABLE | WATCH_JSON, NULL);
	   }
	   sleep(1);
    }
	while(1){
		gps_read(gpsdata);
		printf("lat= %lf lon= %lf\n",gpsdata->fix.latitude,gpsdata->fix.longitude);
	}
    gps_stream(gpsdata, WATCH_DISABLE, NULL);
    gps_close(gpsdata);
}
