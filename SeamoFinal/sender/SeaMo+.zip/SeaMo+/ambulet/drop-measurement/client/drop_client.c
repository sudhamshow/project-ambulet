#include "drop_client.h"

struct send_cntrl prg_ctrl;

int main(){

        pthread_t recv_pkts, send_pkts;
        int iResult;

	bzero(&prg_ctrl, sizeof(prg_ctrl));
	prg_ctrl.pause = 1;

        iResult =
            pthread_create(&recv_pkts, NULL,
                           (void *)receive_thread, NULL);
        if (iResult != 0) {
                printf("recv thread not created : %s \n", strerror(errno));
        }

        iResult =
            pthread_create(&send_pkts, NULL,
                           (void *)send_thread, NULL);
        if (iResult != 0) {
                printf("send thread not created : %s \n",
                       strerror(errno));
        }


        pthread_join(send_pkts, NULL);
        exit(0);

}

void * receive_thread(){
       
	int sockfd_send, sockfd_recv, iresult;
        struct sockaddr_in client_addr, src_addr;
        char recvd_pkt[1500],*rcvd_addr;
        socklen_t src_addr_len = sizeof(struct sockaddr_in);
        struct ctrl_packet *ctrl_rcvd;

        sockfd_send = socket(AF_INET,SOCK_DGRAM,0);
        if(sockfd_send == -1){
                printf("sockfd_send failed: %s", strerror(errno));
        }
        sockfd_recv = socket(AF_INET,SOCK_DGRAM,0);
        if(sockfd_recv == -1){
                printf("sockfd_recv failed: %s", strerror(errno));
        }


        client_addr.sin_family = AF_INET;
        client_addr.sin_port = htons(RECV_PORT);
        client_addr.sin_addr.s_addr = INADDR_ANY;
        bzero(&(client_addr.sin_zero),8);

        if (bind(sockfd_recv,(struct sockaddr *)&client_addr,
            sizeof(struct sockaddr)) == -1)
        {
            perror("Bind");
            exit(1);
        }


        while(1){
                iresult = recvfrom(sockfd_recv, recvd_pkt, MAX_SIZE, 0, (struct sockaddr *)&src_addr, &src_addr_len);
                if(iresult == -1){
                        printf("sendto failed: %s", strerror(errno));
                }else{
			rcvd_addr = inet_ntoa(src_addr.sin_addr);
			printf("source addr :%s\n",rcvd_addr);
			if(strcmp(inet_ntoa(src_addr.sin_addr),prg_ctrl.server_addr)){
				strcpy(prg_ctrl.server_addr,inet_ntoa(src_addr.sin_addr));
				printf("source addr changed!\n");
			}
                        if(!strcmp((char *)&recvd_pkt,"ctrl")){
                                ctrl_rcvd = (struct ctrl_packet*)recvd_pkt;
                                printf("ctrl packet recvd!\t ctrl packet_type=%s \t ctrl_cmd=%s \n",ctrl_rcvd->packet_type,ctrl_rcvd->ctrl_cmd);
				if( !strncmp( ctrl_rcvd->ctrl_cmd, "bitrate",7) ){
					printf("bit rate packet detected!\n");
					check_bitrate( ctrl_rcvd->ctrl_cmd );
				}
				if( !strcmp( ctrl_rcvd->ctrl_cmd, "pause") ){
					printf("pause packet detected!\n");
					prg_ctrl.pause = 1;				
				}
				if( !strcmp( ctrl_rcvd->ctrl_cmd, "start") ){
					printf("start packet detected!\n");
					prg_ctrl.pause = 0;				
				}
				if( !strcmp( ctrl_rcvd->ctrl_cmd, "stop") ){
					printf("bit rate packet detected!\n");
					prg_ctrl.pause = 1;				
					prg_ctrl.no_of_pkts_sent = 0;
				}
				if( !strcmp( ctrl_rcvd->ctrl_cmd, "getstats") ){
					printf("getstats packet detected!\n");
					send_stats();
				}
			}
		}
	}

}

void check_bitrate(char *ctrl_cmd){

	char *tmp_ptr;
	int bit_rate,delay;

	tmp_ptr = strtok(ctrl_cmd," ");
	tmp_ptr = strtok(NULL,"\0");
	printf("%s-tmpptr\n",tmp_ptr);
		
	bit_rate = atoi(tmp_ptr);	
	
	delay = BitRateToDelay(bit_rate);
	
	if(prg_ctrl.delay != delay){
		prg_ctrl.delay = delay;
		prg_ctrl.pause = 0;
	}
}


int BitRateToDelay(int bitrate)
{

        float size_of_packet;
        float number_of_packets, delay;

        size_of_packet = sizeof(struct data_packet);

        number_of_packets = ((bitrate * 1000) / 8) / size_of_packet;

        delay = 1000000 / number_of_packets;

        printf("num pakts : %f sizeof packet : %f Delay : %f\n",
               number_of_packets, size_of_packet, delay);

        return (delay);

}


void send_stats(){

	int sockfd_ctrl, iresult;
	struct sockaddr_in ctrl_addr;
	struct ctrl_packet stats;
	
        sockfd_ctrl = socket(AF_INET,SOCK_DGRAM,0);
        if(sockfd_ctrl == -1){
                printf("sockfd_send failed: %s", strerror(errno));
        }

        ctrl_addr.sin_family = AF_INET;
        ctrl_addr.sin_port = htons(SEND_PORT);
	ctrl_addr.sin_addr.s_addr = inet_addr(prg_ctrl.server_addr);
        bzero(&(ctrl_addr.sin_zero),8);

	strcpy(stats.packet_type,"info");
	sprintf(stats.ctrl_cmd,"%s %d","sent",prg_ctrl.no_of_pkts_sent);

        iresult = sendto(sockfd_ctrl, &stats, sizeof(struct ctrl_packet), 0,  (struct sockaddr*)&ctrl_addr,sizeof(ctrl_addr));
        if(iresult<0){
 	       perror("send failed coz:");
        }


}

void * send_thread(){

        int sockfd_send, iresult;
        struct sockaddr_in  server_addr;
	struct data_packet sendpacket;
	
	strcpy(sendpacket.packet_type,"data");
	strcpy(sendpacket.data, "This is a test packet!");

        sockfd_send = socket(AF_INET,SOCK_DGRAM,0);
        if(sockfd_send == -1){
                printf("sockfd_send failed: %s", strerror(errno));
        }

        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(SEND_PORT);
        bzero(&(server_addr.sin_zero),8);

        while(1){

		if(!prg_ctrl.pause){
        		server_addr.sin_addr.s_addr = inet_addr(prg_ctrl.server_addr);
			prg_ctrl.no_of_pkts_sent ++;
			sendpacket.packet_number = prg_ctrl.no_of_pkts_sent;
			iresult = sendto(sockfd_send, &sendpacket, sizeof(struct data_packet), 0,  (struct sockaddr*)&server_addr,sizeof(server_addr));
			if(iresult<0){
				perror("send failed coz:");
			}
			printf("packet_sent with packet no %d\n",sendpacket.packet_number);
			usleep(prg_ctrl.delay);	
		}
	}
	

}

