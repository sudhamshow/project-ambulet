#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <getopt.h>
#include <pthread.h>

#define MAX_SIZE 	1016
#define INTERFACE_NAME 	4
#define BUFFER_SIZE 	64
#define RECV_PORT 	55570
#define SEND_PORT 	55550


struct data_packet{
	char packet_type[BUFFER_SIZE];
        int packet_number;
        char data [MAX_SIZE];
};

struct ctrl_packet{
	char packet_type[BUFFER_SIZE];
	char ctrl_cmd[BUFFER_SIZE];
};

struct send_cntrl{
	int pause;
	char server_addr[64];
	int delay;
	int no_of_pkts_sent;
};

void * receive_thread();
void * send_thread();
int BitRateToDelay (int);
void check_bitrate(char *ctrl_cmd);
void send_stats();
