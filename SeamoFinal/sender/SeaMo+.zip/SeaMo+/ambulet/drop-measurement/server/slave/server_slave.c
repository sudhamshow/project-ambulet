#include "server_slave.h"

int pkts_rcvd;

int main (int argc,char **argv){

	int sockfd_send, sockfd_recv, iresult;
	struct sockaddr_in client_addr, src_addr, server_addr;
	char recvd_pkt[1500];
	socklen_t src_addr_len = sizeof(struct sockaddr_in);
	struct ctrl_packet *ctrl_rcvd, *stats; 
	struct data_packet *data_rcvd;
	if(argc==1){
		printf("enter the bitrate as argument\n");
		exit(0);
	}	

	sockfd_send = socket(AF_INET,SOCK_DGRAM,0);
	if(sockfd_send == -1){
		printf("sockfd_send failed: %s", strerror(errno));
	}
	sockfd_recv = socket(AF_INET,SOCK_DGRAM,0);
	if(sockfd_recv == -1){
		printf("sockfd_recv failed: %s", strerror(errno));
	}


        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(RECV_PORT);
        server_addr.sin_addr.s_addr = INADDR_ANY;
        bzero(&(server_addr.sin_zero),8);

        if (bind(sockfd_recv,(struct sockaddr *)&server_addr,
            sizeof(struct sockaddr)) == -1)
        {
            perror("Bind");
            exit(1);
        }

	client_addr.sin_family = AF_INET;
	client_addr.sin_addr.s_addr =  inet_addr("202.41.124.46");
	client_addr.sin_port = htons(SEND_PORT);

	ctrl_rcvd = malloc(sizeof(struct ctrl_packet));
	strcpy(ctrl_rcvd->packet_type,"ctrl");
	sprintf(ctrl_rcvd->ctrl_cmd,"%s %s","bitrate",argv[1]);

	iresult = sendto(sockfd_send, ctrl_rcvd, sizeof(struct ctrl_packet), 0,  (struct sockaddr*)&client_addr,sizeof(client_addr));
	if(iresult == -1){
		printf("sendto failed: %s", strerror(errno));
	}

	while(1){
		iresult = recvfrom(sockfd_recv, recvd_pkt, MAX_SIZE, 0, (struct sockaddr *)&src_addr, &src_addr_len);
		if(iresult == -1){
			printf("sendto failed: %s", strerror(errno));
		}else{
			if(!strcmp((char *)&recvd_pkt,"ctrl")){
			       // printf("the string got is %s\n",&recvd_pkt);
//				printf("ctrl packet recvd!\n");
 				ctrl_rcvd = (struct ctrl_packet*)recvd_pkt;
				printf("pkt type %s\tctrlcmd %s\n",ctrl_rcvd->packet_type,ctrl_rcvd->ctrl_cmd);
				iresult = sendto(sockfd_send, ctrl_rcvd, sizeof(struct ctrl_packet), 0,  (struct sockaddr*)&client_addr,sizeof(client_addr));
				if(iresult == -1){
					printf("sendto failed: %s", strerror(errno));
				}
#if 0
				if(!strcmp((char *)ctrl_rcvd->ctrl_cmd,"getstats")){

					strcpy (stats->packet_type, "info");
					sprintf(stats->ctrl_cmd,"%s %d","rcvd",pkts_rcvd);
					send_stats(stats);
				}
#endif
				if(!strcmp(ctrl_rcvd->ctrl_cmd,"stop")){
					pkts_rcvd = 0;
				}
			}else if(!strcmp((char *)&recvd_pkt,"info")){
				stats = (struct ctrl_packet *)recvd_pkt;	
				send_stats(stats);
			}else if(!strcmp((char *)&recvd_pkt,"data")){
			       // printf("the string got is %s\n",&recvd_pkt);
			        data_rcvd = (struct data_packet*)recvd_pkt;
				printf("data packet with no. %d recvd!: %s\n",data_rcvd->packet_number,data_rcvd->data);
				pkts_rcvd++;
			}
		}
	}
return (1);
}

void send_stats(struct ctrl_packet *info_packet){

	struct sockaddr_in ctrl_addr;
	int sockfd_ctrl;
	char temp[32];

	sockfd_ctrl = socket(AF_INET,SOCK_DGRAM,0);

	ctrl_addr.sin_family = AF_INET;
	ctrl_addr.sin_addr.s_addr =  inet_addr("127.0.0.1");
	ctrl_addr.sin_port = htons(CTRL_PORT);
	
	sprintf(temp," %s %d","rcvd",pkts_rcvd);
	strcat(info_packet->ctrl_cmd,temp);
	
	printf("strcated line %s\n",info_packet->ctrl_cmd);
	
	int iresult = sendto(sockfd_ctrl, info_packet, sizeof(struct ctrl_packet), 0,  (struct sockaddr*)&ctrl_addr,sizeof(ctrl_addr));
	if(iresult < 0){
		perror("info send failed");
	}

}
