#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <unistd.h>

#define MAX_SIZE 	1016
#define INTERFACE_NAME 	4
#define BUFFER_SIZE     64
#define SEND_PORT	55570
#define RECV_PORT	55550
#define CTRL_PORT	55580

struct data_packet{
	char packet_type[BUFFER_SIZE];
        int packet_number;
        char data [MAX_SIZE];
};

struct ctrl_packet{
	char packet_type[BUFFER_SIZE];
	char ctrl_cmd[BUFFER_SIZE];
};

int BitRateToDelay (int);
void send_stats(struct ctrl_packet *info_packet);
