#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <getopt.h>
#include <poll.h>

#define MAX_SIZE 	1016
#define INTERFACE_NAME 	4
#define BUFFER_SIZE 	64	
#define RECV_PORT	55580
#define SEND_PORT	55550

struct data_packet{
	char packet_type[BUFFER_SIZE];
        int interface;
        int packet_number;
        char data [MAX_SIZE];
};

struct ctrl_packet{
	char packet_type[BUFFER_SIZE];
	char ctrl_cmd[BUFFER_SIZE];
};

void get_stats();
void get_values(char *ctrl_cmd);
void send_command(char *ctrl_cmd);
