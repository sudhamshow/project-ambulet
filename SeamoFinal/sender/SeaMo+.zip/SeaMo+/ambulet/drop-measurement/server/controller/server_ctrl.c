#include "server_ctrl.h"

int main (int argc, char **argv){

	int  c, digit_optind =0;
	char ctrl_send[64];

        while (1) {
            int this_option_optind = optind ? optind : 1;
            int option_index = 0;
            static struct option long_options[] = {
                {"bitrate", required_argument, 0,  'b' },
                {"start",  	  no_argument, 0,  's' },
                {"stop",   	  no_argument, 0,  'c' },
                {"pause",   	  no_argument, 0,  'p' },
                {"getstats",   	  no_argument, 0,  'g' },
                {0,         		    0, 0,   0 }
             };
             c = getopt_long(argc, argv, "sgcpb:0",
                        long_options, &option_index);
               if (c == -1)
		break;
               switch (c) {
               case 0:
                   printf("option %s", long_options[option_index].name);
                   if (optarg)
                       printf(" with arg %s", optarg);
		   //send_cmd(ctrl_cmd);
                   printf("\n");
                   break;

               case '0':
               case '1':
               case '2':
                   if (digit_optind != 0 && digit_optind != this_option_optind)
                     printf("digits occur in two different argv-elements.\n");

                   digit_optind = this_option_optind;
                   printf("option %c\n", c);
                   break;

               case 'b':
                   printf("option b with value '%s'\n", optarg);
//		   sprintf(ctrl_send.ctrl_cmd,"%s %s","bitrate", optarg);
//		   printf("%s -b\n",ctrl_send.ctrl_cmd);
		   sprintf(ctrl_send,"%s %s","bitrate", optarg);
		   send_command(ctrl_send);
                   break;

               case 's':
                   printf("option s\n");
		   send_command("start");
		   //strcpy(ctrl_send.ctrl_cmd,"start");
		   //ctrl_send.ctrl_cmd = strdup("start");
                   break;

               case 'c':
                   printf("option c\n");
		   send_command("stop");
		   //strcpy(ctrl_send.ctrl_cmd,"start");
		  // strcpy(ctrl_send.ctrl_cmd,"stop");
		   //ctrl_send.ctrl_cmd = strdup("stop");
                   break;

               case 'p':
                   printf("option p\n");
		   send_command("pause");
		   //strcpy(ctrl_send.ctrl_cmd,"start");
		   //strcpy(ctrl_send.ctrl_cmd,"pause");
		   //ctrl_send.ctrl_cmd = strdup("pause");
                   break;

               case 'g':
                   printf("option g\n");
		   get_stats();
                   break;

               case '?':
                   break;

               default:
                   printf("?? getopt returned character code 0%o ??\n", c);
               }
           }
#if 0
	strcpy(ctrl_send.packet_type,"ctrl");

           if (optind < argc) {
               printf("non-option ARGV-elements: ");
               while (optind < argc)
                   printf("%s ", argv[optind++]);
               printf("\n");
           }

	sockfd_send = socket(AF_INET,SOCK_DGRAM,0);
	if(sockfd_send == -1){
		printf("sockfd_send failed: %s", strerror(errno));
	}

	slave_addr.sin_family = AF_INET;
	slave_addr.sin_addr.s_addr =  inet_addr("127.0.0.1");	
	slave_addr.sin_port = htons(SEND_PORT);
	
	iresult = sendto(sockfd_send, &ctrl_send, sizeof(ctrl_send), 0,  (struct sockaddr*)&slave_addr,sizeof(slave_addr));

	if(iresult == -1){
		printf("sendto failed: %s", strerror(errno));
	}else{
		printf("control signal sent: %s\n",ctrl_send.ctrl_cmd);
	}
#endif
return (1);
}


void send_command(char *cmd){

        int sockfd_send, iresult;
        struct sockaddr_in slave_addr;
        struct ctrl_packet ctrl_send;

        sockfd_send = socket(AF_INET,SOCK_DGRAM,0);
        if(sockfd_send == -1){
                printf("sockfd_send failed: %s", strerror(errno));
        }

	strcpy(ctrl_send.packet_type, "ctrl");
	strcpy(ctrl_send.ctrl_cmd, cmd);

        slave_addr.sin_family = AF_INET;
        slave_addr.sin_addr.s_addr =  inet_addr("127.0.0.1");
        slave_addr.sin_port = htons(SEND_PORT);

        iresult = sendto(sockfd_send, &ctrl_send, sizeof(struct ctrl_packet), 0,  (struct sockaddr*)&slave_addr,sizeof(slave_addr));

        if(iresult == -1){
                printf("sendto failed: %s", strerror(errno));
        }else{
                printf("control signal sent: %s\n",ctrl_send.ctrl_cmd);
        }
}


void get_stats(){

	int sockfd_send, sockfd_recv, iresult, pollres;
        struct sockaddr_in slave_addr, recv_addr, src_addr;
        struct ctrl_packet ctrl_send, *ctrl_recv;
	struct pollfd ufd;
	char recv_buf[1500];
	socklen_t src_addr_len = sizeof(struct sockaddr_in);	
       
	 sockfd_send = socket(AF_INET,SOCK_DGRAM,0);
        if(sockfd_send == -1){
                printf("sockfd_send failed: %s", strerror(errno));
        }
        sockfd_recv = socket(AF_INET,SOCK_DGRAM,0);
        if(sockfd_send == -1){
                printf("sockfd_recv failed: %s", strerror(errno));
        }


        slave_addr.sin_family = AF_INET;
        slave_addr.sin_addr.s_addr =  inet_addr("127.0.0.1");
        slave_addr.sin_port = htons(SEND_PORT);

	strcpy(ctrl_send.packet_type, "ctrl");
	strcpy(ctrl_send.ctrl_cmd, "getstats");
	

        iresult = sendto(sockfd_send, &ctrl_send, sizeof(struct ctrl_packet), 0,  (struct sockaddr*)&slave_addr,sizeof(slave_addr));

        if(iresult == -1){
                printf("sendto failed: %s", strerror(errno));
	}

        recv_addr.sin_family = AF_INET;
        recv_addr.sin_port = htons(RECV_PORT);
        recv_addr.sin_addr.s_addr = INADDR_ANY;
        bzero(&(recv_addr.sin_zero),8);

        if (bind(sockfd_recv,(struct sockaddr *)&recv_addr,
            sizeof(struct sockaddr)) == -1)
        {
            perror("Bind");
            exit(1);
        }

	ufd.fd = sockfd_recv;
	ufd.events = POLLIN | POLLPRI; // check for normal or out-of-band
	
	pollres= poll(&ufd, 1, 5000);

	if (pollres == -1) {
	    perror("poll"); // error occurred in poll()
	} else if (pollres == 0) {
    		printf("Timeout occurred! No data after 5 seconds.\n");
	} else {
		if (ufd.revents & POLLIN) {
        		recvfrom(sockfd_recv, recv_buf, sizeof (recv_buf), 0, (struct sockaddr *)&src_addr, &src_addr_len); // receive normal data
			ctrl_recv = (struct ctrl_packet*)recv_buf;
			get_values(ctrl_recv->ctrl_cmd);
    		}
	}	
}

void get_values (char *ctrl_cmd){
        int sent, received, pkt_loss;  
        sscanf (ctrl_cmd, "sent %d rcvd %d\n", &sent, &received);
	pkt_loss = 100 - ((received/sent)*100); 
	printf("stats : packets sent-%d packets-received-%d packet_loss-%d%\n",sent, received, pkt_loss);

}
