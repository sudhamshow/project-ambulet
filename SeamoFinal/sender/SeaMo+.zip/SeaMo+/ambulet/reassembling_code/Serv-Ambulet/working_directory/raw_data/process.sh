#! /bin/bash

#************** Take the file name to process and get the last paket arrived from all the interfaces ******************#

file=$1

last_pkt_0=`grep interface:0 $file | tail -n 1 | awk '{print $5}'`
last_pkt_1=`grep interface:1 $file | tail -n 1 | awk '{print $5}'`
last_pkt_2=`grep interface:2 $file | tail -n 1 | awk '{print $5}'`

#echo "last packet recvd in iface_0: $last_pkt_0 iface_1: $last_pkt_1 iface_2: $last_pkt_2"
#************** Check for the largest packet no from all interfaces******************#

last_pkt=$last_pkt_0
if [ $last_pkt_1 -gt $last_pkt ]
then
last_pkt=$last_pkt_1
fi
if [ $last_pkt_2 -gt $last_pkt ]
then
last_pkt=$last_pkt_2
fi

#************** Check for the number of packets received on every interface ******************#
pkts_recvd_0=`grep interface:0 $file | wc -l`
pkts_recvd_1=`grep interface:1 $file | wc -l`
pkts_recvd_2=`grep interface:2 $file | wc -l`
#echo "no of packets recvd from iface_0: $pkts_recvd_0 iface_1: $pkts_recvd_1 iface_2: $pkts_recvd_2"

pkt_loss_0=$(echo "scale=2;100-(100*$pkts_recvd_0/$last_pkt)" | bc -l)
pkt_loss_1=$(echo "scale=2;100-(100*$pkts_recvd_1/$last_pkt)" | bc -l)
pkt_loss_2=$(echo "scale=2;100-(100*$pkts_recvd_2/$last_pkt)" | bc -l)

#echo "Packet loss from iface_0: $pkt_loss_0 iface_1: $pkt_loss_1 iface_2: $pkt_loss_2"

#************** Sort the packets and put it into a file ******************#
sorted_file="sorted$file"
sort_pkts=`sort -k 5 -n -u $file | wc -l`

#************** Get the stats after sorting ******************#

pkt_loss_sorted=$(echo "scale=2;100-(100*$sort_pkts/$last_pkt)" | bc -l)
consume_0=`sort -k 5 -n -u $file | grep "interface:0" |wc -l`
consume_1=`sort -k 5 -n -u $file | grep "interface:1" |wc -l`
consume_2=`sort -k 5 -n -u $file | grep "interface:2" |wc -l`

#echo $pkt_loss_sorted
echo -e "\nSTATISTICS OF NETWORK PERFORMANCE WITHOUT AMBULET\n"
echo -e "\t\t Interface-1 Interface-2 Interface-3\n"
echo -e "Last Packet \t    $last_pkt_0 \t$last_pkt_1 \t$last_pkt_2"
echo -e "Packets Received    $pkts_recvd_0 \t$pkts_recvd_1 \t$pkts_recvd_2"
echo -e "Packet Loss \t    $pkt_loss_0% \t$pkt_loss_1% \t$pkt_loss_2%"

echo -e "\nSTATISTICS OF NETWORK PERFORMANCE WITH AMBULET\n"
echo -e "Packet Loss \t $pkt_loss_sorted%"
echo -e "Packets From \tIF1: $consume_0 \n\t\tIF2: $consume_1 \n\t\tIF3: $consume_2\n"
