#include "gpsc.h"

double glob_longitude, glob_latitude;
char kml_name[128];


void kml_init (char *name)
{

  FILE *fp;

  fp = fopen (name, "w+");

  fprintf (fp, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
  fprintf (fp, "<kml xmlns=\"http://www.opengis.net/kml/2.2\">\n");
  fprintf (fp, "  <Document>\n");
  fprintf (fp, "    <Style id=\"bluePlacemark\">\n");
  fprintf (fp, "      <IconStyle>\n");
  fprintf (fp, "        <Icon>\n");
  fprintf (fp,
	   "          <href>http://maps.google.com/mapfiles/kml/pushpin/blue-pushpin.png</href>\n");
  fprintf (fp, "        </Icon>\n");
  fprintf (fp, "      </IconStyle>\n");
  fprintf (fp, "    </Style>\n");
  fprintf (fp, "    <Style id=\"redPlacemark\">\n");
  fprintf (fp, "      <IconStyle>\n");
  fprintf (fp, "        <Icon>\n");
  fprintf (fp,
	   "          <href>http://maps.google.com/mapfiles/kml/pushpin/red-pushpin.png</href>\n");
  fprintf (fp, "        </Icon>\n");
  fprintf (fp, "      </IconStyle>\n");
  fprintf (fp, "    </Style>\n");
  fprintf (fp, "    <Style id=\"yellowPlacemark\">\n");
  fprintf (fp, "      <IconStyle>\n");
  fprintf (fp, "        <Icon>\n");
  fprintf (fp,
	   "          <href>http://maps.google.com/mapfiles/kml/pushpin/ylw-pushpin.png</href>\n");
  fprintf (fp, "        </Icon>\n");
  fprintf (fp, "      </IconStyle>\n");
  fprintf (fp, "    </Style>\n");
  fprintf (fp, "    <Style id=\"greenPlacemark\">\n");
  fprintf (fp, "      <IconStyle>\n");
  fprintf (fp, "        <Icon>\n");
  fprintf (fp,
	   "          <href>http://maps.google.com/mapfiles/kml/pushpin/grn-pushpin.png</href>\n");
  fprintf (fp, "        </Icon>\n");
  fprintf (fp, "      </IconStyle>\n");
  fprintf (fp, "    </Style>\n");

  fclose (fp);

}

void
get_time_date (char *day_time)
{

  time_t rawtime;
  struct tm *info;

  time (&rawtime);

  info = localtime (&rawtime);

  strftime (day_time, 32, "%d-%m-%y-%H-%M-%S", info);

}


void insert_placemarker(char *spn,char *file_name)
{
  FILE *my_fp;
  char style_url[128];

  my_fp = fopen(file_name, "a+");


  if (!strncasecmp (spn, "airtel", 4)) {
      sprintf (style_url, "%s%s%s", "<styleUrl>", "#redPlacemark",
               "</styleUrl>");
    }
  if (!strncasecmp (spn, "tata docomo", 4)) {
      sprintf (style_url, "%s%s%s", "<styleUrl>", "#bluePlacemark",
               "</styleUrl>");
    }
  if (!strncasecmp (spn, "bsnl", 4)) {
      sprintf (style_url, "%s%s%s", "<styleUrl>", "#greenPlacemark",
               "</styleUrl>");
    }
  if (!strncasecmp (spn, "wlan0", 4)) {
      sprintf (style_url, "%s%s%s", "<styleUrl>", "#yellowPlacemark",
               "</styleUrl>");
    }


  fprintf (my_fp, "    <Placemark>\n");
  fprintf (my_fp, "      %s\n", style_url);
  fprintf (my_fp, "        <Point>\n");
  fprintf (my_fp, "          <coordinates>%lf,%lf,0</coordinates>\n",
           glob_longitude, glob_latitude);
  fprintf (my_fp, "        </Point>\n");
  fprintf (my_fp, "    </Placemark>\n");

   fclose(my_fp);

}

void get_lat_lon(struct gps_data_t *gpsdata){
  
  if (gps_waiting (gpsdata, 500)) {
      errno = 0;
      if (gps_read (gpsdata) == -1) {
          printf("cant read from gps\n");
          return;
      } else {
          if(!isnan(gpsdata->fix.latitude)){
	     glob_latitude = gpsdata->fix.latitude;
	  }
	  if(!isnan(gpsdata->fix.longitude)){
	     glob_longitude = gpsdata->fix.longitude;	
	  }
      }
  }

}

void termination_handler (int signum) {
  FILE *fp_end;
  
  fp_end = fopen( kml_name, "a+");
  fprintf (fp_end, "</Document>\n");
  fprintf (fp_end, "</kml>\n");
  fclose(fp_end);
      printf ("termination handler\n");
      exit (0);
  }

main (){

  struct gps_data_t *my_gps_data;
  int sock, bytes_read,ret;
  struct sockaddr_in server_addr, client_addr;
  socklen_t addr_len;
  char day_time[32], gps_log_name[128], recv_data[1024];
  char *prev_nw = malloc (30), *curr_nw = malloc (30);
  FILE *fp;
  struct sigaction new_action, old_action;

  my_gps_data = calloc(1,sizeof(struct gps_data_t));	

  /*Connect to GPSD else Quit*/
  ret = gps_open("localhost", "2947", my_gps_data);
  if (ret != 0){
	printf("couldnt connect to gps\n");	
	return;
  }

  /* Set up the structure to specify the new action. */
  new_action.sa_handler = termination_handler;
  sigemptyset (&new_action.sa_mask);
  new_action.sa_flags = 0;

  sigaction (SIGINT, NULL, &old_action);
  if (old_action.sa_handler != SIG_IGN)
  sigaction (SIGINT, &new_action, NULL);

  (void) gps_stream(my_gps_data, WATCH_ENABLE | WATCH_JSON, NULL);

  get_time_date (day_time);

  sprintf (kml_name, "kml_files/%s.kml", day_time);
  sprintf(gps_log_name,"logs/%s",day_time);

  /*Initialise the kml and log files*/
  kml_init(kml_name);

  fp = fopen(gps_log_name,"w+");
  fprintf(fp,"latitude,longitude,current_network\n");
  fclose(fp);

  if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
      perror("Socket");
      exit(1);
  }

  server_addr.sin_family = AF_INET;
  server_addr.sin_port = htons(8989);
  server_addr.sin_addr.s_addr = INADDR_ANY;
  bzero(&(server_addr.sin_zero),8);

  if (bind(sock,(struct sockaddr *)&server_addr, sizeof(struct sockaddr)) == -1) {
      perror("Bind");
      exit(1);
  }

  addr_len = sizeof(struct sockaddr);

  while(1){
       printf("waiting to recv\n");
       bytes_read = recvfrom(sock,recv_data,1024,0,
                            (struct sockaddr *)&client_addr, &addr_len);

       recv_data[bytes_read] = '\0';
       printf("(%s , %d) said : %s \n",inet_ntoa(client_addr.sin_addr),
                                       ntohs(client_addr.sin_port),recv_data);
       /*Read the Latitude and Longitude*/
       get_lat_lon(my_gps_data);
       printf("latitude = %lf longitude = %lf\n", my_gps_data->fix.latitude, my_gps_data->fix.longitude);

       /*Insert Placemarker and fill the log files*/
       insert_placemarker(recv_data,kml_name);

       fp = fopen(gps_log_name,"a+");
       fprintf(fp,"%f,%f,%s \n ",glob_latitude,glob_longitude,recv_data);
       fclose(fp);
//       sleep(1);
  }
   /* When you are done... */
   (void) gps_stream(my_gps_data, WATCH_DISABLE, NULL);
   (void) gps_close (my_gps_data);

}


