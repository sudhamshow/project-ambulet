#include "gpsc.h"

double glob_latitude, glob_longitude;

main ()
{
  struct gps_data_t *gpsdata;
  char recv_data[1024];
  char day_time[32], gps_log_name[128], kml_name[128];
  FILE *fp, *fp_gps;

  // gpsdata = calloc (1, sizeof (struct gps_data_t));

  int i = gps_init (&gpsdata);
  if (i == -1)
    {
      printf ("gps failed to initialize\n");
      return;
    }
  get_time_date (day_time);

  sprintf (gps_log_name, "logs/%s", day_time);
  sprintf (kml_name, "kml_files/%s.kml", day_time);

  kml_init (kml_name);
#if 0
  fp = fopen (gps_log_name, "w+");
  fprintf (fp, "latitude,longitude,current_network\n");
  fclose (fp);
  fp = fopen (gps_log_name, "a+");
#endif

  while (1)
    {
      get_lat_lon (gpsdata);
//        printf("inserting placemarker\n");

//        insert_placemarker("airtel", kml_name);
//      printf("inserted placemarker\n");

//      fprintf(fp,"%lf,%lf,%s \n ",glob_latitude,glob_longitude,"airtel");
      sleep (3);
    }
  fclose (fp);
}


void
get_time_date (char *day_time)
{

  time_t rawtime;
  struct tm *info;

  time (&rawtime);

  info = localtime (&rawtime);

  strftime (day_time, 32, "%d-%m-%y-%H-%M-%S", info);

}

void
kml_init (char kml_name[])
{

  FILE *fp;

  fp = fopen (kml_name, "w+");

  fprintf (fp, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
  fprintf (fp, "<kml xmlns=\"http://www.opengis.net/kml/2.2\">\n");
  fprintf (fp, "  <Document>\n");
  fprintf (fp, "    <Style id=\"bluePlacemark\">\n");
  fprintf (fp, "      <IconStyle>\n");
  fprintf (fp, "        <Icon>\n");
  fprintf (fp,
	   "          <href>http://maps.google.com/mapfiles/kml/pushpin/blue-pushpin.png</href>\n");
  fprintf (fp, "        </Icon>\n");
  fprintf (fp, "      </IconStyle>\n");
  fprintf (fp, "    </Style>\n");
  fprintf (fp, "    <Style id=\"redPlacemark\">\n");
  fprintf (fp, "      <IconStyle>\n");
  fprintf (fp, "        <Icon>\n");
  fprintf (fp,
	   "          <href>http://maps.google.com/mapfiles/kml/pushpin/red-pushpin.png</href>\n");
  fprintf (fp, "        </Icon>\n");
  fprintf (fp, "      </IconStyle>\n");
  fprintf (fp, "    </Style>\n");
  fprintf (fp, "    <Style id=\"yellowPlacemark\">\n");
  fprintf (fp, "      <IconStyle>\n");
  fprintf (fp, "        <Icon>\n");
  fprintf (fp,
	   "          <href>http://maps.google.com/mapfiles/kml/pushpin/ylw-pushpin.png</href>\n");
  fprintf (fp, "        </Icon>\n");
  fprintf (fp, "      </IconStyle>\n");
  fprintf (fp, "    </Style>\n");
  fprintf (fp, "    <Style id=\"greenPlacemark\">\n");
  fprintf (fp, "      <IconStyle>\n");
  fprintf (fp, "        <Icon>\n");
  fprintf (fp,
	   "          <href>http://maps.google.com/mapfiles/kml/pushpin/grn-pushpin.png</href>\n");
  fprintf (fp, "        </Icon>\n");
  fprintf (fp, "      </IconStyle>\n");
  fprintf (fp, "    </Style>\n");

  fclose (fp);

}

void
insert_placemarker (char *spn, char kml_name[])
{
  FILE *fp;
  char style_url[128];

	if(glob_latitude || glob_longitude == 0 ){
		return;
	}

  if (!strncasecmp (spn, "airtel", 4))
    {
      sprintf (style_url, "%s%s%s", "<styleUrl>", "#redPlacemark",
	       "</styleUrl>");
    }
  if (!strncasecmp (spn, "tata docomo", 4))
    {
      sprintf (style_url, "%s%s%s", "<styleUrl>", "#bluePlacemark",
	       "</styleUrl>");
    }
  if (!strncasecmp (spn, "bsnl", 4))
    {
      sprintf (style_url, "%s%s%s", "<styleUrl>", "#greenPlacemark",
	       "</styleUrl>");
    }
  if (!strncasecmp (spn, "wlan0", 4))
    {
      sprintf (style_url, "%s%s%s", "<styleUrl>", "#yellowPlacemark",
	       "</styleUrl>");
    }

  fp = fopen (kml_name, "a+");

  fprintf (fp, "    <Placemark>\n");
  fprintf (fp, "      %s\n", style_url);
  fprintf (fp, "        <Point>\n");
  fprintf (fp, "          <coordinates>%f,%f,0</coordinates>\n",
	   glob_longitude, glob_latitude);
  fprintf (fp, "        </Point>\n");
  fprintf (fp, "    </Placemark>\n");

  fclose (fp);
}

int
gps_init (struct gps_data_t *gpsdata)
{

  struct fixsource_t source;
  gpsd_source_spec (NULL, &source);


  if (gps_open (source.server, source.port, gpsdata) != 0)
    {
      fprintf (stderr, "Could not connect to GPSd\n");
      return (-1);
    }

  gps_stream (gpsdata, WATCH_ENABLE, source.device);

}

void
get_lat_lon (struct gps_data_t *gpsdata)
{

  if (gps_waiting ((const struct gps_data_t *)gps_data, 500))
    {
      errno = 0;
      if (gps_read ((struct gps_data_t *)gps_data) == -1)
	{
	  return;
	}
      else
	{
	  /* Display data from the GPS receiver. */
	  if (gpsdata->fix.mode >= MODE_2D
	      && isnan (gpsdata->fix.latitude) == 0)
	    {
	      glob_latitude = gpsdata->fix.latitude;
	    }

	  if (gpsdata->fix.mode >= MODE_2D
	      && isnan (gpsdata->fix.longitude) == 0)
	    {
	      glob_longitude = gpsdata->fix.longitude;
	    }
	}
    }

}

#if 0
int
getGPSData (struct gps_data_t *gpsdata)
{
  if (gps_open ("localhost", "2947", gpsdata) < 0)
    {
      fprintf (stderr, "Could not connect to GPSd\n");
      return (-1);
    }

  gps_stream (gpsdata, WATCH_ENABLE | WATCH_JSON, NULL);

  fprintf (stderr, "Waiting for gps lock.");
  while (gpsdata->status == 0)
    {
      if (gps_waiting (gpsdata, 500))
	{
	  if (gps_read (gpsdata) == -1)
	    {
	      fprintf (stderr, "GPSd Error\n");
	      gps_stream (gpsdata, WATCH_DISABLE, NULL);
	      gps_close (gpsdata);
	      return (-1);
	      break;
	    }
	  else
	    {
	      if (gpsdata->status > 0)
		{
		  //sometimes if your GPS doesnt have a fix, it sends you data anyways
		  //                    //the values for the fix are NaN. this is a clever way to check for NaN.
		  if (gpsdata->fix.longitude != gpsdata->fix.longitude
		      || gpsdata->fix.altitude != gpsdata->fix.altitude)
		    {
		      fprintf (stderr, "Could not get a GPS fix.\n");
		      gps_stream (gpsdata, WATCH_DISABLE, NULL);
		      sleep (5);
		      gps_close (gpsdata);
		      return (-1);
		      break;
		    }
		  else
		    {
		      fprintf (stderr, "\n");
		    }
		}
	      else
		{
		  fprintf (stderr, ".");
		}
	    }
	}
      else
	{
	  gps_stream (gpsdata, WATCH_ENABLE | WATCH_JSON, NULL);
	}
      sleep (1);
    }
  while (1)
    {
      gps_stream (gpsdata, WATCH_DISABLE, NULL);
      gps_stream (gpsdata, WATCH_ENABLE | WATCH_JSON, NULL);
      gps_read (gpsdata);
      printf ("lat= %lf lon= %lf\n", gpsdata->fix.latitude,
	      gpsdata->fix.longitude);
      sleep (1);
    }
  gps_stream (gpsdata, WATCH_DISABLE, NULL);
  gps_close (gpsdata);
}
#endif
