#include "gpsc.h"
#include <stdio.h>

double glob_latitude,glob_longitude;
struct gps_data_t my_gps_data;

main (){

	struct gps_data_t *gps_data;
        char day_time[32], gps_log_name[128], kml_name[128];
        FILE *fp, *fp_gps;
	struct fixsource_t source;


	gps_data = calloc(1,sizeof(struct gps_data_t));

	gpsd_source_spec(NULL,&source);

//	int ret = gps_open(&source.server, &source.port, &my_gps_data);
	int ret = gps_open("localhost", "2947", &my_gps_data);
	if(ret!=0){
		printf("couldnot connect to gpsd \n");
		return;
	}
	

  get_time_date (day_time);

  sprintf (gps_log_name, "logs/%s", day_time);
  sprintf (kml_name, "kml_files/%s.kml", day_time);

	kml_init(kml_name);

        (void) gps_stream(&my_gps_data, WATCH_ENABLE | WATCH_JSON, NULL);
while(1){


        /* Put this in a loop with a call to a high resolution sleep () in it. */
        if (gps_waiting (&my_gps_data, 500)) {
        	errno = 0;
                if (gps_read (&my_gps_data) == -1) {
                	printf("error reading data\n"); 
                } else {
                    /* Display data from the GPS receiver. */
                      // if (gps_data.set & ...
<<<<<<< HEAD
                      printf("latitude = %lf longitude = %lf\n",gps_data->fix.latitude,gps_data->fix.longitude);
			//insert_placemaker("airtel",kml_name);
#if 0
			glob_latitude = gps_data->fix.latitude;
			glob_longitude = gps_data->fix.longitude;
//			memcpy(&glob_latitude,&gps_data->fix.latitude,sizeof(double));
//			memcpy(&glob_longitude,&gps_data->fix.longitude,sizeof(double));
			insert_placemarker("airtel",kml_name);
			printf("place marker inserted \n");
#endif
=======
                        printf("gps_read executed\n");
			insert_placemarker("airtel",kml_name);
                        sleep (1);
                        continue;
>>>>>>> e614c53b3e18665d537ebb0ce0c95d787d2246a7
                  }
        }
	usleep(100000);
    }
               /* When you are done... */
               (void) gps_stream(&my_gps_data, WATCH_DISABLE, NULL);
               (void) gps_close (&my_gps_data);

}


void
get_time_date (char *day_time)
{

  time_t rawtime;
  struct tm *info;

  time (&rawtime);

  info = localtime (&rawtime);

  strftime (day_time, 32, "%d-%m-%y-%H-%M-%S", info);

}

void
kml_init (char kml_name[])
{

  FILE *fp;

  fp = fopen (kml_name, "w+");

  fprintf (fp, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
  fprintf (fp, "<kml xmlns=\"http://www.opengis.net/kml/2.2\">\n");
  fprintf (fp, "  <Document>\n");
  fprintf (fp, "    <Style id=\"bluePlacemark\">\n");
  fprintf (fp, "      <IconStyle>\n");
  fprintf (fp, "        <Icon>\n");
  fprintf (fp,
	   "          <href>http://maps.google.com/mapfiles/kml/pushpin/blue-pushpin.png</href>\n");
  fprintf (fp, "        </Icon>\n");
  fprintf (fp, "      </IconStyle>\n");
  fprintf (fp, "    </Style>\n");
  fprintf (fp, "    <Style id=\"redPlacemark\">\n");
  fprintf (fp, "      <IconStyle>\n");
  fprintf (fp, "        <Icon>\n");
  fprintf (fp,
	   "          <href>http://maps.google.com/mapfiles/kml/pushpin/red-pushpin.png</href>\n");
  fprintf (fp, "        </Icon>\n");
  fprintf (fp, "      </IconStyle>\n");
  fprintf (fp, "    </Style>\n");
  fprintf (fp, "    <Style id=\"yellowPlacemark\">\n");
  fprintf (fp, "      <IconStyle>\n");
  fprintf (fp, "        <Icon>\n");
  fprintf (fp,
	   "          <href>http://maps.google.com/mapfiles/kml/pushpin/ylw-pushpin.png</href>\n");
  fprintf (fp, "        </Icon>\n");
  fprintf (fp, "      </IconStyle>\n");
  fprintf (fp, "    </Style>\n");
  fprintf (fp, "    <Style id=\"greenPlacemark\">\n");
  fprintf (fp, "      <IconStyle>\n");
  fprintf (fp, "        <Icon>\n");
  fprintf (fp,
	   "          <href>http://maps.google.com/mapfiles/kml/pushpin/grn-pushpin.png</href>\n");
  fprintf (fp, "        </Icon>\n");
  fprintf (fp, "      </IconStyle>\n");
  fprintf (fp, "    </Style>\n");

  fclose (fp);

}

void
insert_placemarker (char *spn, char kml_name[])
{
  FILE *fp;
  char style_url[1024];
/*
	if(glob_latitude || glob_longitude == 0 ){
		return;
	}
*/

  if ( (fp = fopen ("/tmp/abc", "w+")) == NULL) {
     perror("fopen error");
     return;
   }
  fclose(fp);

  return;

  if (!strncasecmp (spn, "airtel", 4)) {
      sprintf (style_url, "%s%s%s", "<styleUrl>", "#redPlacemark",
	       "</styleUrl>");
    }
  if (!strncasecmp (spn, "tata docomo", 4)) {
      sprintf (style_url, "%s%s%s", "<styleUrl>", "#bluePlacemark",
	       "</styleUrl>");
    }
  if (!strncasecmp (spn, "bsnl", 4)) {
      sprintf (style_url, "%s%s%s", "<styleUrl>", "#greenPlacemark",
	       "</styleUrl>");
    }
  if (!strncasecmp (spn, "wlan0", 4)) {
      sprintf (style_url, "%s%s%s", "<styleUrl>", "#yellowPlacemark",
	       "</styleUrl>");
    }



  fprintf (fp, "    <Placemark>\n");
  fprintf (fp, "      %s\n", style_url);
  fprintf (fp, "        <Point>\n");
  fprintf (fp, "          <coordinates>%lf,%lf,0</coordinates>\n",
	   glob_longitude, glob_latitude);
  fprintf (fp, "        </Point>\n");
  fprintf (fp, "    </Placemark>\n");

  fclose (fp);
}

