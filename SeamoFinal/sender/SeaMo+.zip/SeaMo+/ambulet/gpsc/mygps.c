
#include "gpsc.h"

double glob_latitude, glob_longitude;

main ()
{
